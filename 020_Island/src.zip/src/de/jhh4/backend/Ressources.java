package de.jhh4.backend;

/**
 * TODO to be implemented in version 2
 */
public enum Ressources {
	FOOD, WOOD, STONE
}
